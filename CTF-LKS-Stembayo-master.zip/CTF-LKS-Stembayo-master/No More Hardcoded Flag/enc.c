#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main(void){
    char data[100] = "flag{1ts_g00d_to_kn0w_h0w_4pr0gr4M3-w0rk5}";
    int key = 0x129;
    int length;


    length = strlen(data);
    for (int i = 0; i < length; i++){
        data[i] = data[i] ^ key;
        printf("%#04x", data[i]);
        printf(", ");
    }


    for(int i = 0; i < length; i++){
        data[i] = data[i] ^ key;
    }
    printf("\n%s\n", data);
}