#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]){
    
    if (argc != 2){
        printf("Usage: <file> <argument>\n");
        printf("Good Bye\n");
        return 1;
    }

    char flag[4];
    strcpy(flag, argv[1]);
    if (flag[0] != 'f' ){
        printf("Incorrect First Character on Argumen: Should be F\n");
        printf("Good Bye\n");
        return 3;
    }else if (flag[1] != 'l'){
        printf("Incorrect Second Character on Argumen: Should be l\n");
        printf("Good Bye\n");
        return 4;
    }else if (flag[2] != 'a'){
        printf("Incorrect Third Character on Argumen: Can you guess it?\n");
        printf("Good Bye\n");
        return 5;
    }else if (flag[3] != 'g'){
        printf("Incorrect Fourth Character on Argumen: Last character, guess it!!\n");
        printf("Good Bye\n");
        return 6;
    }else{
        unsigned char data[] = {0x4f, 0x45, 0x48, 0x4e, 0x52, 0x18, 0x5d, 0x5a, 0x76, 0x4e, 0x19, 0x19, 0x4d, 0x76, 0x5d, 0x46, 0x76, 0x42, 0x47, 0x19, 0x5e, 0x76, 0x41, 0x19, 0x5e, 0x76, 0x1d, 0x59, 0x5b, 0x19, 0x4e, 0x5b, 0x1d, 0x64, 0x1a, 0x04, 0x5e, 0x19, 0x5b, 0x42, 0x1c, 0x54};
        int key = 0x129;
        int length = sizeof(data);
        for (int i = 0; i < length; i++){
            data[i] = data[i] ^ key;
        }
            printf("\n%s\n", data);
    }
}
