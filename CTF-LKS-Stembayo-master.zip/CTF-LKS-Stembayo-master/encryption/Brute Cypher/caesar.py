alpha = "abcdefghijklmnopqrstuvwxyz"

def encrypt(text, shift):
    encrypted_text = ""
    for char in text:
        if char in alpha:
            position = alpha.find(char)
            new_position = (position + shift) % 26
            new_char = alpha[new_position]
            encrypted_text += new_char
        else:
            encrypted_text += char
    return encrypted_text

text_to_encrypt = "{}"
shift_amount = {x}
encrypted_text = encrypt(text_to_encrypt, shift_amount)
print("Encrypted text:", encrypted_text)



