alpha = "abcdefghijklmnopqrstuvwxyz"

encrypted_text = "uapv{strgneirpthpglxiwdjiztn}"

text_to_decrypt = ""
for i in range(26):
    for char in encrypted_text:
        if char in alpha:
            position = alpha.find(char)
            new_position = (position - i) % 26
            new_char = alpha[new_position]
            text_to_decrypt += new_char
        else:
            text_to_decrypt += char
    if "flag" in text_to_decrypt:
        print("Shift amount:", i)
        print("Decrypted text:", text_to_decrypt)
        break

# Example usage

