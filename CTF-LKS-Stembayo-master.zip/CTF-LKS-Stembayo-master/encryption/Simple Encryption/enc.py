def encrypt(text):
    ct = []
    for char in text:
        encrypted_char = (123 * ord(char) + 18) % 256
        ct.append(encrypted_char)
    return bytes(ct)


# Read text from file
with open('origin.txt', 'r') as file:
    original_text = file.read()

# Encrypt the text
encrypted_text = encrypt(original_text)
print("Encrypted text:", encrypted_text)

f = open('enc.enc', 'w')
f.write(str(encrypted_text.hex()))
f.close()

