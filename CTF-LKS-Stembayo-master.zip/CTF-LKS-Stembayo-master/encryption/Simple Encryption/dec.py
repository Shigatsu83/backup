def decrypt(ct):
    text = []
    for char in ct:
        decrypted_char = ((char - 18) * 179) % 256
        text.append(chr(decrypted_char))
    return ''.join(text)

with open('enc.enc', 'r') as file:
    encryptedfile = file.read()
    hexval = bytes.fromhex(encryptedfile)
    
# Decrypt the text
decrypted_text = decrypt(hexval)
print("Decrypted text:", decrypted_text)

f = open('dec.txt', 'w')
f.write(decrypted_text)
f.close()
