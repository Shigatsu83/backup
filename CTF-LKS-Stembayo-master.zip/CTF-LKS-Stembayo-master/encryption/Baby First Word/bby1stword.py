m = 'flag{th1s_1s_th3_l0ng3st_b4by_f1rst_w0rd_that_1s_4ctu4lly_4_l3g1t_fl4g_and_4_r34lly_l0n5+word_th4t_u_w0nt_sp3ll_1t_1bY_0n3_h3H3_n0w_1G1v3_y0u_4_r4nd0M-nUm83r_4nd_1t_1s_1337_1snt_1t_4ls0_390127893201674985621984789878742934792734298347_NICE-H3H3}'

reversed =''

i = len(m) - 1
while i >= 0:
    reversed = reversed + m[i]
    i = i - 1
    
print(reversed)

enc = reversed
print("SEPARATOR")
print("")
print("")
print("")

translate = ''
i = len(enc) - 1
while i >=0:
    translate = translate + enc[i]
    i = i - 1
print(translate)
##