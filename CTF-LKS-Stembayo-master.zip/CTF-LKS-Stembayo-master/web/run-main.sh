#!/bin/bash
for i in ./*
do
    if [ -d $i ] ; then
        chmod +x $i/run.sh
        cd $i
        ./run.sh
        cd ../
    fi
done