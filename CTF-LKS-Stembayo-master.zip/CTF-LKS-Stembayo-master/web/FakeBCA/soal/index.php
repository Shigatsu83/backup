<?php
    session_start();

    // SQLite database file path
    $dbFile = "user_profiles.db";

// Check if the form is submitted
if (isset($_POST["submit"])) {
    // Get username and password from the form
    $email = $_POST["email"];
    $password = $_POST["password"];

    // // Open connection to SQLite database
    $db = new PDO("sqlite:$dbFile");
    $stmt = $db->prepare("SELECT * FROM user_profiles WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if($user && $password == $user['password']){
        $_SESSION['user'] = $user['username'];
        $_SESSION['status'] = "Login Success!";
        header("Location: page.php?user_id=".$user['id']);
    }else{
        echo "<script>alert('login failed')</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login BCA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body class="text-center">
<div class="container my-xl-5">
    <div class="row">
      <div class="col-md-4 offset-md-4">
        <div class="card my-5">
            <div class="card-header">
                <h3 class="card-title mt-3">Login</h3>
            </div>
          <form class="card-body cardbody-color p-lg-5" method="POST">
            <div class="mb-3">
              <input type="text" name="email" class="form-control" id="Username" aria-describedby="emailHelp"
                placeholder="Email">
            </div>
            <div class="mb-3">
              <input type="password" name="password" class="form-control" id="password" placeholder="password">
            </div>
            <div class="text-center"><button type="submit" class="btn btn-primary px-5 mb-5 w-100" name="submit">Login</button></div>
            <div id="emailHelp" class="form-text text-center mb-2 text-dark">
                Not Registered? <a href="#" class="text-dark fw-bold"> Create an Account</a>
            </div>
          </form>
      </div>
    </div>
  </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>