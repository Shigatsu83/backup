#!/bin/bash
docker rm -f fake_bca
docker build --tag=fake_bca .
docker run -d  -p 1338:80 --rm --name=fake_bca -it fake_bca