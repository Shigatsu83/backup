#!/bin/bash
docker rm -f filtered_lfi
docker build --tag=filtered_lfi .
docker run -d --cap-add NET_RAW -p 1337:80 --rm --name=filtered_lfi -it filtered_lfi