#!/bin/bash
docker rm -f newjeans
docker build --tag=newjeans .
docker run -d --cap-add NET_RAW -p 1339:80 --rm --name=newjeans -it newjeans