<?php
session_start();

// Check if user is already logged in
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    // Redirect to another page if already logged in
    header("Location: index.php");
    exit;
}
// Function to hash cookie value
function hashing_val($value) {
    return hash('sha256', $value);
}


// Function to authenticate user
function authenticate_user($email, $password) {

    $trueVal = hashing_val('true');
    $falseVal = hashing_val('false');
    // Connect to SQLite database
    $db = new SQLite3('users.db');

    // Prepare and execute query to check user credentials
    $query = $db->prepare('SELECT id, is_admin FROM users WHERE email = :email AND password = :password');
    $query->bindValue(':email', $email, SQLITE3_TEXT);
    $query->bindValue(':password', $password, SQLITE3_TEXT);
    $result = $query->execute();
    $row = $result->fetchArray(SQLITE3_ASSOC);

    //Check if user exists and password is correct
    if ($row && $row['id']) {
        // Start session and set user ID
        session_start();
        $_SESSION['logged_in'] = true;
        $_SESSION['user_id'] = $row['id'];

        // Determine if user is admin
        $is_admin = ($row['is_admin'] == 1);

        if(!isset($_COOKIE['admin'])){
            if ($is_admin) {    
                // Set admin cookie
                setcookie('admin', $trueVal, time() + 3600, '/');
            } else {
                // Set regular user cookie
                setcookie('admin', $falseVal, time() + 3600, '/');
            }
        }
        header("Location: main-redirect.php");
        exit;
    } else {
        return false;
    }
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate email and password (not implemented for demonstration purposes)
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Authenticate user
    if (authenticate_user($email, $password)) {
        // Authentication successful
    } else {
        // Authentication failed
        $error_message = "Invalid email or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Custom styles -->
    <style>
        body {
            background-color: #f0f0f0;
        }
        .login-container {
            width: 360px;
            margin: auto;
            margin-top: 100px;
            padding: 30px;
            border-radius: 8px;
            background-color: #fff;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
        }
        .login-logo {
            text-align: center;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <div class="login-container" >
        <div class="login-logo" >
            <img src="https://ih1.redbubble.net/image.4979938093.1590/raf,360x360,075,t,fafafa:ca443f4786.jpg " alt="Google Logo" height="60">
        </div>
        <h2 class="text-center mb-4">Sign in</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="mb-3">
                <label for="email" class="form-label">Email address</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Sign in</button>
        </form>
        <?php if(isset($error_message)) { ?>
            <div class="alert alert-danger mt-3" role="alert"><?php echo $error_message; ?></div>
        <?php } ?>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>
