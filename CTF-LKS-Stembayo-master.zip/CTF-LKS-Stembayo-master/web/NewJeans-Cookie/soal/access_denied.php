<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Denied</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .error-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #f8d7da; /* Bootstrap danger color */
            border: 1px solid #f5c6cb; /* Bootstrap danger color */
            padding: 20px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="error-container text-center">
        <h1 class="text-danger">Access Denied!</h1>
        <h2 class="text-danger">Whoa whoa, hold on! You are not Bunnies are you?</h2>
    </div>
</body>
</html>
