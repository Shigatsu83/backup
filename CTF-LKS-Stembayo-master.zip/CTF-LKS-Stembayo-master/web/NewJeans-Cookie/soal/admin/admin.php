<?php
// Start session

session_start();

// Check if user is logged in;
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    // Redirect to login page if not logged in
    header("Location: index.php");
    exit;
}

// Get username from session
$id = $_SESSION['user_id'];
$db = new SQLite3('../users.db');

$query = $db->prepare('SELECT * FROM users WHERE id = :id');
$query->bindValue(':id', $id, SQLITE3_TEXT);
$result = $query->execute();

$row = $result->fetchArray(SQLITE3_ASSOC);

// Logout function
function logout() {
    // Unset all session variables
    $_SESSION = array();
    // Destroy the session
    session_destroy();
    // Set the cookie's expiration time to a past time to delete it
    setcookie('admin', '', time() - 3600, "/"); // Set the expiration time to one hour ago

    // Redirect to login page
    header("Location: ../index.php");
    exit;
}

// Check if logout action is requested
if (isset($_GET['logout'])) {
    logout();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .profile-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .logout-btn {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <?php include '../material/navbar.php'; ?>


    <div class="profile-container" style="margin-top:5rem;">
        <h1 class="mb-4">Welcome <?= $row["name"];?>!</h1>
        <p>Email: <?= $row['email']; ?></p>
        <!-- Logout Button -->
        <a href="?logout=true" class="btn btn-danger logout-btn">Logout</a>
    </div>
</body>
</html>

