<?php
session_start();

// Check if user is already logged in
if (!isset($_COOKIE['admin'])) {
    // Redirect to another page if already logged in
    header("Location: index.php");
    exit;
}
function hashing_val($value) {
    return hash('sha256', $value);
}

$cookie_value = $_COOKIE['admin'] ?? null;
    // Redirect based on the cookie value
    if ($cookie_value === hashing_val('true')) {
        // Redirect the user to the admin page
        header("Location: admin/admin.php");
        exit;
    } elseif ($cookie_value === hashing_val('false')) {
        // Redirect the user to the regular user page
        header("Location: profile.php");
        exit;
    } else {
        // Handle the case where the cookie value is not recognized
        echo "Invalid cookie value";
        // Optionally, you can redirect the user to a default page or display an error message
        }
?>