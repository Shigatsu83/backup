<?php
function hashing_val($value) {
    return hash('sha256', $value);
}
// Check if the admin cookie is set and its value is 'true'
$admin_cookie = $_COOKIE['admin'] ?? null;

if ($admin_cookie === hashing_val('true')) {
    // Redirect the user to the admin page
    header("Location: admin/admin.php");
    exit;
}
