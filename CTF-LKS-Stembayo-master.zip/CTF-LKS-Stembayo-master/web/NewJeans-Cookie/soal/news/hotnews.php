<?php
function hashing_val($value) {
    return hash('sha256', $value);
}
// Start session
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true && !isset($_COOKIE['admin'])) {
    // Redirect to login page if not logged in
    header("Location: ../index.php");
    exit;
}
// Check if the admin cookie is set and its value is 'true'
$admin_cookie = $_COOKIE['admin'] ?? null;

if ($admin_cookie !== hashing_val('true')) {
    // Redirect the user to a different page or display an access denied message
    header("Location: ../access_denied.php");
    exit;
}


// Get username from session
$id = $_SESSION['user_id'];
$db = new SQLite3('../users.db');

$query = $db->prepare('SELECT * FROM users WHERE id = :id');
$query->bindValue(':id', $id, SQLITE3_TEXT);
$result = $query->execute();

$row = $result->fetchArray(SQLITE3_ASSOC);


function logout() {
    // Unset all session variables
    $_SESSION = array();
    // Destroy the session
    session_destroy();
    // Set the cookie's expiration time to a past time to delete it
    setcookie('admin', '', time() - 3600, "/"); // Set the expiration time to one hour ago

    // Redirect to login page
    header("Location: ../index.php");
    exit;
}

// Check if logout action is requested
if (isset($_GET['logout'])) {
    logout();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kpop Idol Members</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        /* Adjusting column sizes */
        .left-section {
            width: 80%;
        }
        .right-section {
            width: 20%;
        }
        /* Centering content in columns */
        .card-body {
            text-align: center;
        }
        /* Remove border from news section */
        .list-group {
            border: none;
        }
        /* Resize images */
        .card-img-top {
            height: 20rem; /* Adjust the height as needed */
            object-fit: cover;
        }
    </style>
</head>
<body>
<?php include '../material/navbar.php'; ?>

    <div class="container" style="margin-top: 5rem;">
        <div class="row">
            <!-- Left section for displaying Kpop idol members -->
            <div class="col-md-9 left-section">
                <h2>NewJeans Members</h2>
                <div class="row">
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <img src="https://asset-a.grid.id/crop/0x0:0x0/x/photo/2023/11/22/allkpop_1690144054_hannijpg-20231122053142.jpg" class="card-img-top" alt="Hanni">
                            <div class="card-body">
                                <h5 class="card-title">Hanni</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <img src="https://i.pinimg.com/736x/b6/1c/31/b61c315187098bf88b6300480edcc0a3.jpg" class="card-img-top" alt="Danielle">
                            <div class="card-body">
                                <h5 class="card-title">Danielle</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <img src="https://t-2.tstatic.net/tribunnewswiki/foto/bank/images/Minji-NewJeans.jpg" class="card-img-top" alt="Minji">
                            <div class="card-body">
                                <h5 class="card-title">Minji</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <img src="https://o-cdn-cas.sirclocdn.com/parenting/images/295291564_771585300853703_6296141.width-500.format-webp.webp" class="card-img-top" alt="Hyein">
                            <div class="card-body">
                                <h5 class="card-title">Hyein</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <img src="https://static.promediateknologi.id/crop/0x0:0x0/750x500/webp/photo/2023/04/19/Haerin-NewJeans-699633787.jpg" class="card-img-top" alt="Haerin">
                            <div class="card-body">
                                <h5 class="card-title">Haerin</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Right section for displaying hot news -->
            <div class="col-md-3 right-section">
                <h2>Hot News!</h2>
                <ul class="list-group">
                    <li class="list-group-item">flag{n0w-y0u-D0nT-wANt_to-Sp1lL-uR-c00k1e}</li>
                    <li class="list-group-item">Hot News 2</li>
                    <li class="list-group-item">Hot News 3</li>
                    <li class="list-group-item">Hot News 4</li>
                    <li class="list-group-item">Hot News 5</li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>
