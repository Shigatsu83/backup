#include <stdio.h>
#include <string.h>

int main() {
    char password[] = "reversing1337";
    printf("Enter the password: ");
    char input[100];
    scanf("%s", input);
    if (strcmp(input, password) == 0) {
        printf("Correct password!\n");
        printf("Flag: flag{Ez_h4rdc0d3d_p4ssw0rd}\n");

    } else {
        printf("Incorrect password!\n");
    }
    return 0;
}